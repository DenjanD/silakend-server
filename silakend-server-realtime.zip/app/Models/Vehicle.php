<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Str;
use Illuminate\Database\Eloquent\SoftDeletes;

class Vehicle extends Model
{
    use HasFactory;
    use SoftDeletes;

    protected static function boot() {
        parent::boot();
        static::creating(function ($model) {
            if ( ! $model->getKey()) {
                $model->{$model->getKeyName()} = (string) Str::uuid();
            }
        });
    }

    public function getIncrementing()
    {
        return false;
    }

    public function getKeyType()
    {
        return 'string';
    }

    protected $fillable = [
        'name',
        'year',
        'tax_date',
        'valid_date',
        'license_number',
        'distance_count',
        'vcategory_id',
    ];

    protected $primaryKey = 'vehicle_id';

    //null saat di get
    public function category() {
        return $this->hasOne(VehicleCategory::class, 'vcategory_id', 'vcategory_id')
                    ->select(['vcategory_id','name']);
    }
}
